import java.io.*;
import java.util.Random;
import workshop.policies.*;
import workshop.orders.*;
import workshop.*;

public class WorkshopScheduler{
    public static void main(String[] args)throws Exception{
        if(args.length<6){
            System.out.print("La cantidad de datos ingresados no es valida\nrevisar cada uno de los parametros.\nEl ingreso debe ser de la siguiente forma: \n-politica(minusculas) rango_tiempo_ingreso sedan microbus coupe precio \ne.g.\n-fcfs 1.5-3 2 1 4 1500 \n");
            
        }else{
            String policy = args[0];
            String intervalo = args[1];
            int n1 = (int)(Double.parseDouble(intervalo.substring(0,intervalo.indexOf("-")))*1000);
            int n2 = (int)(Double.parseDouble(intervalo.substring(intervalo.indexOf("-")+1,intervalo.length()))*1000);
            int sedantime = (int)(Double.parseDouble(args[2])*1000);
            int bustime = (int)(Double.parseDouble(args[3])*1000);
            int coupetime = (int)(Double.parseDouble(args[4])*1000);
            String price = args[5];
            ThreadQ lector;
            boolean bandera = true;
            BufferedReader bf = new BufferedReader(new InputStreamReader(System.in));
            switch(policy){
                case "-fcfs":
                    ThreadFCFS orden = new ThreadFCFS(n1,n2,sedantime,bustime,coupetime,price);
                    orden.start();
                    lector = new ThreadQ(orden.getPolicy());
                    lector.start();
                    while(bandera){
                        if(!orden.isEmpty()){
                            if(orden.next() instanceof SedanOrder){
                                System.out.println("\nPolítica seleccionada: First Come First Served");
                                System.out.println("\nActualmente se atiende a: "+orden.next().getType()+", "+orden.next().getTotal()+" pieza(s) (correlativo #"+orden.next().getOrder()+")");
                                int totalpieces = orden.next().getTotal();
                                SedanOrder so = (SedanOrder) orden.remove();
                                System.out.println("\n\nOrdenes pendientes: "+ orden.toString());
                                System.out.println("---------------\n\n");
                                lector.addTotalTime(totalpieces*sedantime);
                                try{Thread.sleep(totalpieces*sedantime);
                                }
                                catch(Exception e){
                                }
                                System.out.println("\n\n---------------");
                                System.out.println("Orden completa! Se completó "+so.getType()+" que necesitaba "+so.getTotal()+" pieza(s) (correlativo #"+so.getOrder()+")");
                                System.out.println("Precio Original: "+so.getPrice());
                                int descuento = (int)(((Double.parseDouble(so.getPrice())-Double.parseDouble(so.getTotalPrice()))*100)/Double.parseDouble(so.getPrice()));
                                System.out.println("Descuento: "+descuento+"%");
                                System.out.println("Total a pagar: "+so.getTotalPrice());
                            }
                            if(orden.next() instanceof CoupeOrder){
                                System.out.println("\nPolítica seleccionada: First Come First Served");
                                System.out.println("\nActualmente se atiende a: "+orden.next().getType()+", "+orden.next().getTotal()+" pieza(s) (correlativo #"+orden.next().getOrder()+")");
                                int totalpieces = orden.next().getTotal();
                                CoupeOrder co = (CoupeOrder)orden.remove();
                                System.out.println("\n\nOrdenes pendientes: "+orden.toString());
                                System.out.println("---------------\n\n");
                                lector.addTotalTime(totalpieces*coupetime);
                                try{
                                    Thread.sleep(totalpieces*coupetime);
                                    System.out.println("\n\n---------------");
                                    System.out.println("Orden completa! Se completó "+co.getType()+" que necesitaba "+co.getTotal()+" pieza(s) (correlativo #"+co.getOrder()+")");
                                    System.out.println("Precio Original: "+co.getPrice());
                                    int descuento = (int)(((Double.parseDouble(co.getPrice())-Double.parseDouble(co.getTotalPrice()))*100)/Double.parseDouble(co.getPrice()));
                                    System.out.println("Descuento: "+descuento+"%");
                                    System.out.println("Total a pagar: "+co.getTotalPrice());
                                }
                                catch(Exception e){
                                    System.out.println(e);
                                }
                            }
                            if(orden.next() instanceof BusOrder){
                                System.out.println("\nPolítica seleccionada: First Come First Served");
                                System.out.println("\nActualmente se atiende a: "+orden.next().getType()+", "+orden.next().getTotal()+" pieza(s) (correlativo #"+orden.next().getOrder()+")");
                                int totalpieces = orden.next().getTotal();
                                BusOrder bo = (BusOrder)orden.remove();
                                System.out.println("\nOrdenes pendientes: "+orden.toString());
                                System.out.println("---------------\n\n");
                                lector.addTotalTime(totalpieces*bustime);
                                try{Thread.sleep(totalpieces*bustime);}
                                catch(Exception e){
                                }
                                System.out.println("\n\n---------------");
                                System.out.println("Orden completa! Se completó "+bo.getType()+" que necesitaba "+bo.getTotal()+" pieza(s) (correlativo #"+bo.getOrder()+")");
                                System.out.println("Precio Original: "+bo.getPrice());
                                int descuento = (int)(((Double.parseDouble(bo.getPrice())-Double.parseDouble(bo.getTotalPrice()))*100)/Double.parseDouble(bo.getPrice()));
                                System.out.println("Descuento: "+descuento+"%");
                                System.out.println("Total a pagar: "+bo.getTotalPrice()+"\n\n");
                            }
                        }
                    }
                    
                case "-lcfs":
                    ThreadLCFS ordenlcfs = new ThreadLCFS(n1,n2,sedantime,bustime,coupetime,price);
                    lector = new ThreadQ(ordenlcfs.getPolicy());
                    ordenlcfs.start();
                    lector.start();
                    while(lector.off()){

                        if (!ordenlcfs.isEmpty()){
                            if(ordenlcfs.next() instanceof SedanOrder){
                                System.out.println("\nPolítica seleccionada: Last Come First Served");
                                System.out.println("\nActualmente se atiende a: "+ordenlcfs.next().getType()+", "+ordenlcfs.next().getTotal()+" pieza(s) (correlativo #"+ordenlcfs.next().getOrder()+")");
                                int totalpieces = ordenlcfs.next().getTotal();
                                SedanOrder so = (SedanOrder) ordenlcfs.remove();
                                System.out.println("\n\nOrdenes pendientes: "+ ordenlcfs.toString());
                                System.out.println("---------------\n\n");
                                lector.addTotalTime(totalpieces*sedantime);
                                try{Thread.sleep(totalpieces*sedantime);}
                                catch(Exception e){
                                }
                                System.out.println("\n\n---------------");
                                System.out.println("Orden completa! Se completó "+so.getType()+" que necesitaba "+so.getTotal()+" pieza(s) (correlativo #"+so.getOrder()+")");
                                System.out.println("Precio Original: "+so.getPrice());
                                int descuento = (int)(((Double.parseDouble(so.getPrice())-Double.parseDouble(so.getTotalPrice()))*100)/Double.parseDouble(so.getPrice()));
                                System.out.println("Descuento: "+descuento+"%");
                                System.out.println("Total a pagar: "+so.getTotalPrice());
                            }
                            if(ordenlcfs.next() instanceof CoupeOrder){
                                System.out.println("\nPolítica seleccionada: Last Come First Served");
                                System.out.println("\nActualmente se atiende a: "+ordenlcfs.next().getType()+", "+ordenlcfs.next().getTotal()+" pieza(s) (correlativo #"+ordenlcfs.next().getOrder()+")");
                                int totalpieces = ordenlcfs.next().getTotal();
                                CoupeOrder co = (CoupeOrder)ordenlcfs.remove();
                                System.out.println("\n\nOrdenes pendientes: "+ordenlcfs.toString());
                                System.out.println("---------------\n\n");
                                lector.addTotalTime(totalpieces*coupetime);
                                try{Thread.sleep(totalpieces*coupetime);}
                                catch(Exception e){
                                }
                                System.out.println("\n\n---------------");
                                System.out.println("Orden completa! Se completó "+co.getType()+" que necesitaba "+co.getTotal()+" pieza(s) (correlativo #"+co.getOrder()+")");
                                System.out.println("Precio Original: "+co.getPrice());
                                int descuento = (int)(((Double.parseDouble(co.getPrice())-Double.parseDouble(co.getTotalPrice()))*100)/Double.parseDouble(co.getPrice()));
                                System.out.println("Descuento: "+descuento+"%");
                                System.out.println("Total a pagar: "+co.getTotalPrice());
                            }
                            if(ordenlcfs.next() instanceof BusOrder){
                                System.out.println("\nPolítica seleccionada: Last Come First Served");
                                System.out.println("\nActualmente se atiende a: "+ordenlcfs.next().getType()+", "+ordenlcfs.next().getTotal()+" pieza(s) (correlativo #"+ordenlcfs.next().getOrder()+")");
                                int totalpieces = ordenlcfs.next().getTotal();
                                BusOrder bo = (BusOrder)ordenlcfs.remove();
                                System.out.println("\nOrdenes pendientes: "+ordenlcfs.toString());
                                System.out.println("---------------\n\n");
                                lector.addTotalTime(totalpieces*bustime);
                                try{Thread.sleep(totalpieces*bustime);}
                                catch(Exception e){
                                }
                                System.out.println("\n\n---------------");
                                System.out.println("Orden completa! Se completó "+bo.getType()+" que necesitaba "+bo.getTotal()+" pieza(s) (correlativo #"+bo.getOrder()+")");
                                System.out.println("Precio Original: "+bo.getPrice());
                                int descuento = (int)(((Double.parseDouble(bo.getPrice())-Double.parseDouble(bo.getTotalPrice()))*100)/Double.parseDouble(bo.getPrice()));
                                System.out.println("Descuento: "+descuento+"%");
                                System.out.println("Total a pagar: "+bo.getTotalPrice()+"\n\n");
                            }
                        }
                    }
                case "-rr":
                    break;
                default:
                    System.out.println("Solo existen las siguientes politicas: \n-fcfs\n-lcls\n-rr");
                    break;
            }
        }
    }
}