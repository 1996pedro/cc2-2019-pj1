/* SedanOrder.java */
/**
 ** Hecho por: 
 ** Carnet: 
 ** Sección: 
**/
package workshop.orders;

import java.util.Random;
/** Representa una orden de tipo Sedan */
public class CoupeOrder extends PaintOrder {
    protected String type;
    protected String price;
    
    public CoupeOrder(int number, String plate, int total, double time, String price){
        super(number,plate,total,time);
        this.type = "COUPE";
        this.price = price;
    }

    public String getType(){
        return type;
    }

    public String getPrice(){
        return price;
    }
    public String getTotalPrice(){
        State state = getState().DONE;
        switch(state){
            case DONE:
                Random rnd = new Random();
                int descuento = rnd.nextInt(6)+4;
                return Double.toString(Double.parseDouble(price)*(descuento/100));
            default:
                return "?";
        }
    }

    public void end(){
        this.state = State.DONE;
    }
}
