/* SedanOrder.java */
/**
 ** Hecho por: 
 ** Carnet: 
 ** Sección: 
**/
package workshop.orders;


/** Representa una orden de tipo Sedan */
public class BusOrder extends PaintOrder {
    protected String type;
    protected String price;
    
    public BusOrder(int number, String plate, int total, double time, String price){
        super(number,plate,total,time);
        this.type = "COUPE";
        this.price = price;
    }

    public String getType(){
        return this.type;
    }
    public String getPrice(){
        return this.price;
    }
    public String getTotalPrice(){
        State state = getState().DONE;
        switch(state){
            case DONE:
                int descuento =Integer.parseInt(getLicensePlate().substring(2,3));
                return Double.toString(Double.parseDouble(price)*(descuento/100));
            default:
                return "?";
        }
    }

    public void end(){
        this.state = State.DONE;
    }
}
