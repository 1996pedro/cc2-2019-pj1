/* SedanOrder.java */
/**
 ** Hecho por: 
 ** Carnet: 
 ** Sección: 
**/
package workshop.orders;


/** Representa una orden de tipo Sedan */
public class SedanOrder extends PaintOrder {
    private String type;
    private String price;
    
    public SedanOrder(int number, String plate, int total, double time, String price){
        super(number,plate,total,time);
        this.type = "SEDAN";
        this.price = price;
    }

    public String getType(){
        return this.type;
    }

    public String getTotalPrice(){
        State state = getState().DONE;
        switch(state){
            case DONE:
                return Double.toString(getTotal() * Double.parseDouble(price));
            default:
                return "?";
        }    
    }

    public String getPrice(){
        return this.price;
    }

    public void end(){
        this.state = State.DONE;
    }
}
