package workshop;
import workshop.policies.*;
import java.io.*;

public class ThreadQ extends Thread{
	int totaltime = 0;
    Policy orden;
    Boolean bandera=true;
    public ThreadQ(Policy orden){
        super();
        this.orden = orden;
        this.bandera = true;
    }

    public void addTotalTime(int time){
        totaltime+= time;
    }

    public boolean off(){
        return bandera;
    }

    public void run(){
        BufferedReader bf = new BufferedReader(new InputStreamReader(System.in));
        String q;

        try{
            q = bf.readLine();
            if(q.equals("q")){
                System.out.println("Total de Ordenes Procesadas: "+orden.getProcessedOrders());
                System.out.println("Ordenes pendientes de procesar: "+orden.getQueuedOrders());
                System.out.println("Tiempo promedio por orden: "+(totaltime/orden.getProcessedOrders()));
                this.bandera = false;
            }
        }catch(IOException e){
            System.out.println(e);
        }
    }
}