package workshop;

import java.io.*;
import java.util.Random;
import workshop.policies.*;
import workshop.orders.*;

public class ThreadLCFS extends Thread{
	int n1,n2,sedantime,bustime,coupetime;
	String price;
	LCFS stack; 
	public ThreadLCFS(int n1, int n2, int sedantime, int bustime, int coupetime, String price){
		super();
		this.n1 = n1;
		this.n2 = n2;
		this.sedantime = sedantime;
		this.bustime = bustime;
		this.coupetime = coupetime;
		this.price = price;
		this.stack = new LCFS();
	}
	public void run(){
		Random rnd = new Random();
		int cont = 1;
		while(true){
			int time = n1 + rnd.nextInt((n2+1)-n1);
			int opt = rnd.nextInt(3);
			int pieces = rnd.nextInt(10)+1;
			int d1 =rnd.nextInt(10);
			int d2 =rnd.nextInt(10);
			int d3 =rnd.nextInt(10);
			char l1 =(char)(rnd.nextInt(26)+65);
			char l2 =(char)(rnd.nextInt(26)+65);
			char l3 =(char)(rnd.nextInt(26)+65);
			String plate = Integer.toString(d1)+Integer.toString(d2)+Integer.toString(d3)+l1+l2+l3;
			RandomOrder(opt,pieces,plate,cont++);
			try{
				Thread.sleep(time);
			} catch (Exception e){
			}
		}
	}
	public void RandomOrder(int opt,int pieces, String plate, int cont){
		switch(opt){
				case 0: SedanOrder nuevo = new SedanOrder(cont,plate,pieces,coupetime,price);
						stack.add(nuevo); 
						System.out.println("\nNuevo ingreso! Se ingresó un "+nuevo.getType()+" que necesita "+nuevo.getTotal()+" piezas (correlativo #"+nuevo.getOrder()+")");
						break;
				case 1: BusOrder nuevo1 = new BusOrder(cont,plate,pieces,sedantime,price);
						stack.add(nuevo1); 
						System.out.println("\nNuevo ingreso! Se ingresó un "+nuevo1.getType()+" que necesita "+nuevo1.getTotal()+" piezas (correlativo #"+nuevo1.getOrder()+")");
						break;
				case 2: CoupeOrder nuevo2 = new CoupeOrder(cont,plate,pieces,bustime,price);
						stack.add(nuevo2); 
						System.out.println("\nNuevo ingreso! Se ingresó un "+nuevo2.getType()+" que necesita "+nuevo2.getTotal()+" piezas (correlativo #"+nuevo2.getOrder()+")");
						break;
			}
	}
	public boolean isEmpty(){
		return stack.isEmpty();
	}
	public PaintOrder next(){
		return stack.next();
	}
	public PaintOrder remove(){
		return stack.remove();
	}
	public String toString(){
		return stack.toString();
	}
	public int getCurrentOrders(){
		return stack.getCurrentOrders();
	}
	public int getProcessedOrders(){
		return stack.getProcessedOrders();
	}
	public int getQueuedOrders(){
		return stack.getQueuedOrders();
	}

	public Policy getPolicy(){
		return this.stack;
	}		
}