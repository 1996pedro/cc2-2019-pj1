package workshop.policies;

import java.util.concurrent.*;
import java.util.Random;
import java.io.*;


import workshop.orders.*;

public class FCFS extends Policy{
	protected ConcurrentLinkedQueue<PaintOrder> list;
	public FCFS(){
		super();
		list = new ConcurrentLinkedQueue<PaintOrder>();
	}
	public void add(PaintOrder p){
		list.add(p);
		super.queuedOrders++; 
	}
	public boolean isEmpty(){
		return list.isEmpty();
	}
	public PaintOrder remove(){
		
		super.currentOrders=1;
		super.processedOrders++;
		super.queuedOrders--; 
		PaintOrder po = list.poll();
		po.end();
		return po;

	}
	public PaintOrder next(){
		PaintOrder po = list.peek();
		State state = po.getState();
		state = State.PROCESSING;
		return po;
	}

	public String toString(){
		String str = "";
		int cont = 0;
		ConcurrentLinkedQueue<PaintOrder> nueva = new ConcurrentLinkedQueue<PaintOrder>();
		PaintOrder aux;
		while(cont < list.size()){		
			aux=list.poll();
			nueva.add(aux);
			str+= aux.toString()+" | ";
			cont++;
		}
		cont = 0;
		while(cont < nueva.size()){
			list.add(nueva.poll());
			cont++;
		}
		return str;
	}
}