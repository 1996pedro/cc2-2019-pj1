package workshop.orders;

import java.util.LinkedList;
import java.util.Random;
import java.io.*;

public class RR extends Policy  {
	

}