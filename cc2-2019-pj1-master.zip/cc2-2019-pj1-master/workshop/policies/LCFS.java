package workshop.policies;

import java.util.Stack;
import java.util.Random;
import java.io.*;


import workshop.orders.*;

public class LCFS extends Policy{
	protected Stack<PaintOrder> stack;
	public LCFS(){
		super();
		stack = new Stack<PaintOrder>();
	}

	public boolean isEmpty(){
		return stack.empty();
	}
	
	public void add(PaintOrder p){
		stack.push(p);
		super.queuedOrders++; 
	}

	public PaintOrder remove(){
		
		super.currentOrders=1;
		super.processedOrders++;
		super.queuedOrders--; 
		PaintOrder po = stack.pop();
		po.end();
		return po;

	}
	public PaintOrder next(){
		PaintOrder po = stack.peek();
		State state = po.getState();
		state = State.PROCESSING;
		return po;
	}

	public String toString(){
		Object[] aux = new Object[stack.toArray().length];
        for(int i=0;i<aux.length;i++)
        	aux[i] = stack.toArray()[i];
        String str = "";
        for(int i=0;i<aux.length;i++)
	       	str = str+" | " + aux[i];
        return str;
	}
}